import com.github.dhiraj072.randomwordgenerator.exceptions.DataMuseException;
import spoon.Launcher;
import spoon.refactoring.CtRenameLocalVariableRefactoring;
import spoon.refactoring.RefactoringException;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import spoon.reflect.code.CtLocalVariable;
import spoon.reflect.code.CtStatement;
import spoon.reflect.declaration.CtClass;
import spoon.reflect.declaration.CtElement;
import spoon.reflect.declaration.CtMethod;
import spoon.reflect.visitor.filter.NamedElementFilter;
import spoon.reflect.visitor.filter.TypeFilter;
import spoon.reflect.factory.Factory;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Random;
import com.github.dhiraj072.randomwordgenerator.RandomWordGenerator;
import com.github.dhiraj072.randomwordgenerator.datamuse.WordsRequest;
import com.github.dhiraj072.randomwordgenerator.datamuse.DataMuseRequest;

public class Main {
    public static void changeLocalVariableName(CtLocalVariable<?> localVariable, String newName) throws RefactoringException {
        new CtRenameLocalVariableRefactoring().setTarget(localVariable).setNewName(newName).refactor();
    }

    public static String RandomFunctionName(WordsRequest customRequest) throws DataMuseException {
        String randomWord = RandomWordGenerator.getRandomWord(customRequest);
        String NewName = randomWord + "Test";
        return NewName;
    }

    ;

    public static String RandomString(WordsRequest customRequest) throws DataMuseException {
        String randomWord = RandomWordGenerator.getRandomWord(customRequest);
        return '"' + randomWord + '"';
    }

    ;

    public static String RandomVarName(WordsRequest customRequest) throws DataMuseException {
        String randomWord = RandomWordGenerator.getRandomWord(customRequest);
        return randomWord;
    }

    ;

    public static void addStatment(Factory fac, CtMethod function, WordsRequest customRequest) throws DataMuseException {
        int type = 0;
        Random r = new Random();
        char c = (char) (r.nextInt(26) + 'a');
        CtStatement stat = fac.createCodeSnippetStatement("");
        type = r.nextInt(3);
        switch (type) {
            case 0:
                stat = fac.createCodeSnippetStatement( "int " + c + "=" + r.nextInt(10000));
                break;
            case 1:
                stat = fac.createCodeSnippetStatement("float " + c + "=" + r.nextFloat());
                break;
            case 2:
                stat = fac.createCodeSnippetStatement("String " + c + "=" + RandomString(customRequest));
                break;
            default:

        }
        int bound = function.getBody().getStatements().size();
        int index = r.nextInt(bound)  ;
        function.getBody().addStatement(index, stat);
    }


    public static void main(String[] args) throws IOException, DataMuseException {


        Launcher launcher = new Launcher();
        String baseDir = "D:/PFE/code/dataset/";
        File folder = new File(baseDir);
        Pattern pattern = Pattern.compile("(\\\"(.*?)\\\")|(\\'(.*?)\\')");
        WordsRequest RandomString = new DataMuseRequest().topics("string");
        WordsRequest RandomFunction = new DataMuseRequest().topics("test", "function", "method");
        WordsRequest RandomVar = new DataMuseRequest().topics("var");
        Factory factory = new Launcher().createFactory();

        for (final File fileEntry : folder.listFiles()) {

            Path fileName = Path.of(baseDir + fileEntry.getName());
            String code = Files.readString(fileName);
            String TestName =   Arrays.asList( fileEntry.getName().split("@")).get(0) ;
            List<String> NameParts= Arrays.asList(TestName.split("\\.")) ;
            String MethodName = NameParts.get(NameParts.size() - 1 ).strip() ;


            /* change strings */

            Matcher matcher = pattern.matcher(code);
            while (matcher.find()) {
                String s = matcher.group(1);

                try {
                    if (s.length() > 10){
                        code = code.replace(s, RandomString(RandomString));}
                    } catch (Exception e) {

                    }

            }

            // Rename variables
                code = "class A { \n" + code + "}";
                CtClass parsed_code = Launcher.parseClass(code);
                List<CtMethod> tabMethods= parsed_code.filterChildren(new NamedElementFilter<>(CtMethod.class,MethodName)).list();

                if (tabMethods.size() > 0) {
                    CtMethod TestMethod  = tabMethods.get(0) ;
                    List<CtLocalVariable> ls = TestMethod.getElements(new TypeFilter(CtLocalVariable.class));

                    Random r = new Random();
                    for (CtLocalVariable l : ls) {
                        char c = (char)(r.nextInt(26) + 'a');
                        try {
                            changeLocalVariableName(l,  RandomVarName(RandomVar) /*or c */ );
                        } catch (Exception e) {

                        }
                    }

                    // add variables
                    addStatment(factory,TestMethod,RandomString);

                     // Rename method
                    TestMethod.setSimpleName(RandomFunctionName(RandomFunction));

                    // save
                    PrintWriter writerTests = new PrintWriter("D:/PFE/code/augmented_dataset/" + "v2_" + fileEntry.getName(), StandardCharsets.UTF_8);
                    writerTests.println(TestMethod);
                    writerTests.close();

                }


        }
    }
}

